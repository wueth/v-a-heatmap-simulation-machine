#########################################################
### Simulation Machine of Telematics v-a heatmaps                               
### Speed bucket from 5 to 20 km/h
### Author: Mario V. Wuthrich  
### Date: 22.11.2017                                  
### Version: 1                                        
### Literature: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3070069
#########################################################


##########################################
#########  load necessary R packages
##########################################

require(MASS)

##########################################
#########  function simulating heatmaps
##########################################

heatmap.simulation.machine <- function(n=1000, alpha=c(3,1,1,1), version=1, seed=200){
       # load parameters
       W3 <- as.matrix(read.table(file=paste("./Parameters/W3_version",version,".csv", sep=""), header=FALSE, sep=";"))
       W4 <- as.matrix(read.table(file=paste("./Parameters/W4_version",version,".csv", sep=""), header=FALSE, sep=";"))
       # initialize the simulation algorithm
       q1 <- ncol(W3)-1
       p1 <- nrow(W3)
       z_sim <- array(1, dim=c(q1+1, n))
       a <- array(NA, length(alpha))
       set.seed(seed)
       for (c1 in 1:4){a[c1]<-runif(n=1, max=alpha[c1])}
       a <- a/sum(a)
       n0 <- array(0, length(alpha)+1)
       n0[2:4] <- round(n*a[1:3],0)
       n0[5] <- n - sum(n0[2:4])
       # simulate the bottleneck neurons
       for (c1 in 1:4){
         Sigma <- data.matrix(read.table(paste("./Parameters/Covariances_C",c1,".csv", sep=""), header=FALSE, sep=";"))
         Means <- data.matrix(read.table(paste("./Parameters/Means_C",c1,".csv", sep=""), header=FALSE, sep=";"))
         simulation <- mvrnorm(n = n0[c1+1], Means, Sigma)
         z_sim[-1,(sum(n0[1:c1])+1):(sum(n0[1:(c1+1)]))] <- t(simulation)
               }
       order1 <- sample(1:ncol(z_sim),ncol(z_sim),replace = FALSE)
       z_sim <- z_sim[,order1]
       # calculate the heatmaps 
       z3 <- array(1, c(p1+1, n))
       z3[-1,] <- 2*((1+exp(-2*W3 %*% z_sim))^(-1))-1 
       mu_t <- exp(W4 %*% z3)
       t(mu_t/colSums(mu_t)[col(mu_t)])
        }
        
        
        
##########################################
#########  function simulating the heatmaps
##########################################
##########################################
### n is the number of car drivers
### alpha describes the portfolio mix (needs to be of dimension 4)
##########################################

xx <- heatmap.simulation.machine(n=2000)  
N0 <- sqrt(ncol(xx))      

# illustrate individual drivers        
driver <- 500
filled.contour(t(matrix(xx[driver,], nrow=N0, ncol=N0)), col=rainbow(36), nlevels=36, xlab="speed in km/h", ylab="acceleration in m/s^2",  main=list(paste("v-a heatmap of driver ",driver,sep=""), cex=1.5), zlim = c(0,0.018), x=((1:N0)-1)/(N0-1)*15+5,y=((1:N0)-1)/(N0-1)*4-2)
     
